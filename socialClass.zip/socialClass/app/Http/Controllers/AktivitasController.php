<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Aktivitas;
use Storage;

class AktivitasController extends Controller
{




    public function index()
    {
        $data_aktivitas = \App\Aktivitas::all();
        return view('aktivitas.index', ['data_aktivitas' => $data_aktivitas]);
    }






    public function create(Request $request)
    {

           $request->validate([
            'nama_aktivitas' => 'required',
            'tanggal' => 'required',
            'waktu' => 'required',
            'tempat' => 'required',
            'deskripsi' => 'required',
            'gambar' => 'required',
            'status' => 'required'
        ]);

        if ($request->hasFile('gambar')) {
            $gambar = $request -> file('gambar');
            $ext = $gambar->getClientOriginalExtension();
            if ($request->file('gambar')->isValid()) {
                $gambar_nama = date('YmdHis'). ".$ext";
                $upload_path = 'gambarupload';
                $request -> file('gambar')->move($upload_path, $gambar_nama);
                $data_aktivitas['gambar'] = $upload_path;
            }
        }

        \App\Aktivitas::create($request->all());
        return redirect('/aktivitas')->with('status', 'Data Aktivitas Berhasil Ditambahkan!');
    }






    public function store(Request $request)
    {
        $data_aktivitas = $request->all();

        $request->validate([
            'nama_aktivitas' => 'required',
            'tanggal' => 'required',
            'waktu' => 'required',
            'tempat' => 'required',
            'deskripsi' => 'required',
            'gambar' => 'required',
            'status' => 'required|in:Belum,Selesai'
        ]);


        if ($request->hasFile('gambar')) {
            $gambar = $request -> file('gambar');
            $ext = $gambar->getClientOriginalExtension();
            if ($request->file('gambar')->isValid()) {
                $gambar_nama = date('YmdHis'). ".$ext";
                $upload_path = 'gambarupload';
                $request -> file('gambar')->move($upload_path, $gambar_nama);
                $data_aktivitas['gambar'] = $upload_path;
            }
        }
    }










    public function show(Aktivitas $data_aktivitas)
    {
        return view('aktivitas.show', compact(
            'data_aktivitas'
        ));
    }






    public function edit(Aktivitas $data_aktivitas)
    {
        return view('aktivitas/edit', compact('data_aktivitas'));
    }







    public function update(Request $request, Aktivitas $data_aktivitas)
    {

        // $data_aktivitas = \App\Aktivitas::find($id);
        // // $request->validate(all());
        // $data_aktivitas->update($request->all());
        // return redirect('/aktivitas')->with('status', 'Data Aktivitas Berhasil Diubah!');

        $request->validate([
            'nama_aktivitas' => 'required',
            'tanggal' => 'required',
            'waktu' => 'required',
            'tempat' => 'required',
            'deskripsi' => 'required',
            'status' => 'required|in:Belum,Selesai'
        ]);


        $data_aktivitas::where('id', $data_aktivitas->id)
            ->update([
                'nama_aktivitas' => $request->nama_aktivitas,
                'tanggal' => $request->tanggal,
                'waktu' => $request->waktu,
                'tempat' => $request->tempat,
                'deskripsi' => $request->deskripsi,
                'status' => $request->status
            ]);
        return redirect('/aktivitas')->with('status', 'Data Aktivitas Berhasil Diubah!');
    }








    public function destroy(Aktivitas $data_aktivitas)
    {
        // $aktivitas = \App\Aktivitas::find($id);
        // $aktivitas->delete($aktivitas);
        // return redirect('/aktivitas')->with('sukses', 'Data berhasil dihapus');

        Aktivitas::destroy($data_aktivitas->id);
        return redirect('/aktivitas')->with('status', 'Data Aktivitas Berhasil Dihapus!');
    }
}
