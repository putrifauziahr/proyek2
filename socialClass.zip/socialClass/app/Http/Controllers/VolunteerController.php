<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Volunteer;

class VolunteerController extends Controller
{


    public function dashboardvolunteer()
    {

        return view('volunteer.dashboardvolunteer');
    }


    public function index()
    {
        $data_volunteer = \App\Volunteer::all();
        return view('volunteer.index', ['data_volunteer' => $data_volunteer]);
    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }


    public function show(Volunteer $data_volunteer)
    {
        return view('volunteer.show', compact(
            'data_volunteer'
        ));
    }


    public function edit(Volunteer $data_volunteer)
    {
        return view('volunteer/edit', compact('data_volunteer'));
    }


    public function update(Request $request, Volunteer $data_volunteer)
    {
        $request->validate([
            'nama' => 'required',
            'alamat' => 'required',
            'desa' => 'required',
            'kecamatan' => 'required',
            'tgl_lahir' => 'required',
            'jk'        => 'required|in:Laki-Laki,Perempuan',
            'kontak' => 'required',
            'profesi' => 'required',
            'bidang' => 'required',
            'email' => 'required',
            'password' => 'required',
            'konfir_pass' => 'required'
        ]);


        $data_volunteer::where('id', $data_volunteer->id)
            ->update([
                'nama' => $request->nama,
                'alamat' => $request->alamat,
                'desa' => $request->desa,
                'kecamatan' => $request->kecamatan,
                'tgl_lahir' => $request->tgl_lahir,
                'jk'        => $request->jk,
                'kontak' => $request->kontak,
                'profesi' => $request->profesi,
                'bidang' => $request->bidang,
                'email' => $request->email,
                'password' => $request->password,
                'konfir_pass' => $request->konfir_pass
            ]);
        return redirect('/datavolunteer')->with('status', 'Data Volunteer Berhasil Diubah!');
    }


    public function destroy(Volunteer $data_volunteer)
    {
        Volunteer::destroy($data_volunteer->id);
        return redirect('/datavolunteer')->with('status', 'Data Volunteer Berhasil Dihapus!');
    }
}
