<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Aktivitas;

class ActController extends Controller
{
    public function index()
    {
    	$data_aktivitas =\App\Aktivitas::all();
    	return view('act', ['data_aktivitas' => $data_aktivitas]);
    }

    public function show(Aktivitas $data_aktivitas)
    {
    	return view('showact', compact('data_aktivitas'));
    }
}
