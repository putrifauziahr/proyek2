<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVolunteersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('volunteers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nama');
            $table->string('alamat');
            $table->string('desa');
            $table->string('kecamatan');
            $table->date('tgl_lahir');
            $table->enum('jk', ['Laki-Laki', 'Perempuan']);
            $table->string('kontak');
            $table->string('profesi');
            $table->string('bidang');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('konfir_pass');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('volunteers');
    }
}
